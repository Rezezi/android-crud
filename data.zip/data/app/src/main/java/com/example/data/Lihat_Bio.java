package com.example.data;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity; // Pastikan Anda mengimpor AppCompatActivity

public class Lihat_Bio extends AppCompatActivity {
    protected Cursor cursor;
    DataHelper dbHelper;
    Button ton2;
    TextView text1, text2, text3, text4, text5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lihat_bio);

        dbHelper = new DataHelper(this);

        // Menghubungkan elemen UI dengan id
        text1 = findViewById(R.id.textViewliat1);
        text2 = findViewById(R.id.textViewliat2);
        text3 = findViewById(R.id.textViewliat3);
        text4 = findViewById(R.id.textViewliat4);
        text5 = findViewById(R.id.textViewliat5);

        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Mendapatkan data dari intent
        String nama = getIntent().getStringExtra("nama");

        // Query untuk mendapatkan data dari database
        cursor = db.rawQuery("SELECT * FROM biodata WHERE nama = ?", new String[]{nama});

        // Menampilkan data jika ditemukan
        if (cursor != null && cursor.moveToFirst()) {
            text1.setText(cursor.getString(0));  // Nomor
            text2.setText(cursor.getString(1));  // Nama
            text3.setText(cursor.getString(2));  // Tanggal Lahir
            text4.setText(cursor.getString(3));  // Jenis Kelamin
            text5.setText(cursor.getString(4));  // Alamat
        }

        // Tombol untuk kembali
        ton2 = findViewById(R.id.button1);
        ton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                // Kembali ke activity sebelumnya
                finish();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (cursor != null) {
            cursor.close(); // Menutup cursor untuk menghindari memory leak
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate menu, menambahkan item ke action bar jika ada
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
}
