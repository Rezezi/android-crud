package com.example.data;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Update extends AppCompatActivity {
    protected Cursor cursor;
    DataHelper dbHelper;
    Button ton1, ton2;
    EditText text1, text2, text3, text4, text5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        // Inisialisasi database helper
        dbHelper = new DataHelper(this);

        // Inisialisasi EditText
        text1 = findViewById(R.id.editTextup1);
        text2 = findViewById(R.id.editTextup2);
        text3 = findViewById(R.id.editTextup3);
        text4 = findViewById(R.id.editTextup4);
        text5 = findViewById(R.id.editTextup5);

        // Mendapatkan data dari intent
        String nama = getIntent().getStringExtra("nama");

        // Mendapatkan data dari database
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        cursor = db.rawQuery("SELECT * FROM biodata WHERE nama = ?", new String[]{nama});

        // Jika data ditemukan, tampilkan di EditText
        if (cursor.moveToFirst()) {
            text1.setText(cursor.getString(0));  // no
            text2.setText(cursor.getString(1));  // nama
            text3.setText(cursor.getString(2));  // tgl
            text4.setText(cursor.getString(3));  // jk
            text5.setText(cursor.getString(4));  // alamat
        }

        // Menutup cursor setelah digunakan
        cursor.close();

        // Inisialisasi tombol update (ton1) dan batal (ton2)
        ton1 = findViewById(R.id.button1);
        ton2 = findViewById(R.id.button2);

        // Fungsi untuk update data
        ton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                db.execSQL("UPDATE biodata SET nama = ?, tgl = ?, jk = ?, alamat = ? WHERE no = ?",
                        new String[]{
                                text2.getText().toString(),  // nama
                                text3.getText().toString(),  // tgl
                                text4.getText().toString(),  // jk
                                text5.getText().toString(),  // alamat
                                text1.getText().toString()   // no
                        });
                Toast.makeText(getApplicationContext(), "Berhasil", Toast.LENGTH_LONG).show();
                MainActivity.ma.RefreshList();  // Refresh list di MainActivity
                finish();
            }
        });

        // Fungsi untuk membatalkan update
        ton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                finish();  // Menutup activity
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate menu; tambahkan item ke action bar jika diperlukan
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
}
